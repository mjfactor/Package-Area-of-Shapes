from areaofShapesLib.myFunctions import ArithmeticOperations

