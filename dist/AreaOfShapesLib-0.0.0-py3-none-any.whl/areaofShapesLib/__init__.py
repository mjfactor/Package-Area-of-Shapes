from areaofShapesLib.myFunctions import *

